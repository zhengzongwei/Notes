# Copyright 2019 Ram Rachum and collaborators.
# This program is distributed under the MIT license.

def bar_function(y):
    x = 7 * y
    return x
